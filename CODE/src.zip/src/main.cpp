
#include <Arduino.h>
#include "FlySkyReceiver.h"
#include "Motor.h"
#include "OLED_1306.h"

unsigned long previousMillis = 0; // Variable para almacenar el tiempo anterior
const unsigned long interval = 200; // Intervalo en milisegundos


// Inicialización de motores en sus respectivos pines y canales PWM
Motor motor_a(26, 27, 0, 1);  // Motor A en pines 26 y 27, usando canales PWM 0 y 1
Motor motor_b(12, 14, 2, 3);  // Motor B en pines 33 y 32, usando canales PWM 2 y 3
RMotor rodillo(5,4);

// Crear instancia de FlySkyReceiver usando Serial2 y el temporizador 1 para ESP32
FlySkyReceiver Homero(Serial2, 1);

OLED screen;  // Crear una instancia de la clase OLED

void setup() {
  Serial.begin(115200);          // Comunicación serial para depuración
  Serial.println("Iniciando lectura de 10 canales de FlySky");
  Serial2.begin(115200, SERIAL_8N1, 16, 17); // Configura UART2 en GPIO16 (RX2) y GPIO17 (TX2)
  screen.begin();
  screen.clearDisplay();
}


void loop() {
  // Leer el tiempo actual
  unsigned long currentMillis = millis();
   Homero.AllChannels();             // Leer y mapear valores de los canales
        

// Verificar si ha pasado el intervalo
  if (currentMillis - previousMillis >= interval) {
    previousMillis = currentMillis; // Actualizar el tiempo anterior

    //Homero.printChannelValues();// Imprimir valores mapeados en el monitor serial
   
    screen.clearDisplay();
    // Actualizar pantalla
    screen.printTextS(("CH1: " + String(Homero.getChannelPWM(1))).c_str(), 0, 0);
    screen.printTextS(("CH2: " + String(Homero.getChannelPWM(2))).c_str(), 0, 8);
    screen.printTextS(("ESC: " + String(Homero.getChannelPWM(3))).c_str(), 0, 16);
    screen.printTextS(("CH4: " + String(Homero.getChannelPWM(4))).c_str(), 0, 24);
    screen.printTextS(("CH5: " + String(Homero.getChannelPWM(5))).c_str(), 0, 32);
    screen.printTextS(("CH6: " + String(Homero.getChannelPWM(6))).c_str(), 64, 0);
    screen.printTextS(("CH7: " + String(Homero.getChannelPWM(7))).c_str(), 64, 8);
    screen.printTextS(("CH8: " + String(Homero.getChannelPWM(8))).c_str(), 64, 16);
    screen.printTextS(("SPD: " + String(Homero.getChannelPWM(9))).c_str(), 64, 24);
    screen.printTextS(("CH10: " + String(Homero.getChannelPWM(10))).c_str(), 64, 32);
    screen.display();
  }

    // Configurar velocidades de los motores
    motor_a.setSpeed(Homero.getChannelPWM(2));
    motor_b.setSpeed(Homero.getChannelPWM(1));
    rodillo.speedrodillo(Homero.getChannelPWM(9));
  

  // Puedes agregar aquí otras tareas que no se bloqueen
}


